﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // ======================== ЗАДАЧА 2.1: Система уравнений ========================
        private void BtnSolveSystem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Парсим коэффициенты
                double a = double.Parse(tbA.Text);
                double b = double.Parse(tbB.Text);
                double c = double.Parse(tbC.Text);
                double d = double.Parse(tbD.Text);
                double n = double.Parse(tbE.Text);
                double f = double.Parse(tbF.Text);

                // Вычисляем определитель матрицы
                // Матрица: | a  b |
                //          | d  e |
                double determinant = a * n - b * d;

                string result = "";

                if (Math.Abs(determinant) > 0.0001) // Система имеет уникальное решение
                {
                    // По правилу Крамера:
                    // x = (c*e - b*f) / determinant
                    // y = (a*f - c*d) / determinant
                    double x = (c * n - b * f) / determinant;
                    double y = (a * f - c * d) / determinant;

                    result = $"✓ Система имеет ЕДИНСТВЕННОЕ решение:\n\n";
                    result += $"x = {x:F6}\n";
                    result += $"y = {y:F6}\n\n";
                    result += $"Проверка:\n";
                    result += $"Уравнение 1: {a}*{x:F4} + {b}*{y:F4} = {a * x + b * y:F4} (ожидалось {c})\n";
                    result += $"Уравнение 2: {d}*{x:F4} + {e}*{y:F4} = {d * x + n * y:F4} (ожидалось {f})";
                }
                else // determinant == 0
                {
                    // Проверяем линейную зависимость уравнений
                    if (Math.Abs(a) < 0.0001 && Math.Abs(b) < 0.0001 && Math.Abs(d) < 0.0001 && Math.Abs(n) < 0.0001)
                    {
                        if (Math.Abs(c) < 0.0001 && Math.Abs(f) < 0.0001)
                        {
                            result = "✓ Система имеет БЕСКОНЕЧНОЕ множество решений\n\n";
                            result += "Оба уравнения: 0 = 0 (идентичны)";
                        }
                        else
                        {
                            result = "✗ Система НЕ ИМЕЕТ решений\n\n";
                            result += "Несовместимые уравнения: 0 = c и 0 = f (где c ≠ 0 или f ≠ 0)";
                        }
                    }
                    else
                    {
                        // Проверяем, пропорциональны ли коэффициенты
                        double ratio_a = (Math.Abs(a) > 0.0001) ? d / a : (Math.Abs(d) > 0.0001 ? double.PositiveInfinity : 1);
                        double ratio_b = (Math.Abs(b) > 0.0001) ?n / b : (Math.Abs(n) > 0.0001 ? double.PositiveInfinity : 1);
                        double ratio_c = (Math.Abs(c) > 0.0001) ? f / c : (Math.Abs(f) > 0.0001 ? double.PositiveInfinity : 1);

                        if (Math.Abs(ratio_a - ratio_b) < 0.0001 && Math.Abs(ratio_b - ratio_c) < 0.0001)
                        {
                            result = "✓ Система имеет БЕСКОНЕЧНОЕ множество решений\n\n";
                            result += "Уравнения линейно зависимы (одно - кратное другому)\n";
                            result += $"Отношение: {ratio_a:F4}";
                        }
                        else
                        {
                            result = "✗ Система НЕ ИМЕЕТ решений\n\n";
                            result += "Уравнения противоречивы (прямые параллельны)\n";
                            result += "Коэффициенты при x и y пропорциональны, но свободные члены - нет";
                        }
                    }
                }

                tbResult21.Text = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\nПроверьте корректность введённых данных", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ======================== ЗАДАЧА 2.2: Системы счисления ========================
        private void BtnConvert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int number = int.Parse(tbDecimal.Text);

                if (number < 0)
                {
                    MessageBox.Show("Введите неотрицательное число", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Конвертируем в двоичную систему
                string binary = ConvertToBinary(number);

                // Конвертируем в восьмеричную систему
                string octal = ConvertToOctal(number);

                // Конвертируем в шестнадцатеричную систему
                string hexadecimal = ConvertToHexadecimal(number);

                tbBinary.Text = binary;
                tbOctal.Text = octal;
                tbHex.Text = hexadecimal;

                // Информация о процессе
                string notes = "Алгоритм работает путём последовательного деления на основание системы счисления\n";
                notes += $"Исходное число: {number}\n";
                notes += $"Двоичная (основание 2): {binary}\n";
                notes += $"Восьмеричная (основание 8): {octal}\n";
                notes += $"Шестнадцатеричная (основание 16): {hexadecimal}";

                tbConversionNotes.Text = notes;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Конвертация в двоичную систему
        private string ConvertToBinary(int number)
        {
            if (number == 0) return "0";

            string result = "";
            while (number > 0)
            {
                result = (number % 2) + result;
                number /= 2;
            }
            return result;
        }

        // Конвертация в восьмеричную систему
        private string ConvertToOctal(int number)
        {
            if (number == 0) return "0";

            string result = "";
            while (number > 0)
            {
                result = (number % 8) + result;
                number /= 8;
            }
            return result;
        }

        // Конвертация в шестнадцатеричную систему
        private string ConvertToHexadecimal(int number)
        {
            if (number == 0) return "0";

            string hexChars = "0123456789ABCDEF";
            string result = "";
            while (number > 0)
            {
                result = hexChars[number % 16] + result;
                number /= 16;
            }
            return result;
        }

        // ======================== ЗАДАЧА 2.3: Класс Student ========================
        private void BtnCalculateStatus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = tbStudentName.Text;
                string studentNumber = tbStudentNumber.Text;
                string gradesText = tbGrades.Text;

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(studentNumber) || string.IsNullOrWhiteSpace(gradesText))
                {
                    MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Парсим оценки
                var grades = gradesText.Split(',')
                    .Select(g => g.Trim())
                    .Where(g => !string.IsNullOrWhiteSpace(g))
                    .Select(g => double.Parse(g))
                    .ToList();

                if (grades.Count == 0)
                {
                    MessageBox.Show("Введите хотя бы одну оценку", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Создаём объект Student
                Student student = new Student(name, studentNumber, grades);
                double averageGrade = student.CalculateAverageGrade();
                string status = student.DetermineStatus();

                string result = $"📊 Информация о студенте:\n\n";
                result += $"Имя: {student.Name}\n";
                result += $"Номер студента: {student.StudentNumber}\n";
                result += $"Оценки: {string.Join(", ", grades)}\n";
                result += $"Средний балл: {averageGrade:F2}\n";
                result += $"Статус: {status}\n\n";

                if (status == "Отличник")
                    result += "🌟 Отличная работа! Средний балл 4.5 и выше";
                else if (status == "Хороший")
                    result += "👍 Хороший результат! Средний балл от 3.5 до 4.4";
                else
                    result += "📈 Удовлетворительно. Старайтесь улучшить результаты!";

                tbStudentResult.Text = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\nПроверьте формат оценок (используйте числа, разделённые запятыми)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Класс Student
        public class Student
        {
            public string Name { get; set; }
            public string StudentNumber { get; set; }
            public List<double> Grades { get; set; }

            public Student(string name, string studentNumber, List<double> grades)
            {
                Name = name;
                StudentNumber = studentNumber;
                Grades = grades;
            }

            public double CalculateAverageGrade()
            {
                if (Grades.Count == 0) return 0;
                return Grades.Sum() / Grades.Count;
            }

            public string DetermineStatus()
            {
                double averageGrade = CalculateAverageGrade();

                if (averageGrade >= 4.5)
                    return "Отличник";
                else if (averageGrade >= 3.5)
                    return "Хороший";
                else
                    return "Удовлетворительный";
            }
        }

        // ======================== ЗАДАЧА 2.4: Удаление дубликатов ========================
        private void BtnRemoveDuplicates_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string input = tbArrayInput.Text;
                if (string.IsNullOrWhiteSpace(input))
                {
                    MessageBox.Show("Введите массив элементов", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Парсим входные данные
                var originalArray = input.Split(',')
                    .Select(x => x.Trim())
                    .ToList();

                // Удаляем дубликаты с сохранением порядка
                var uniqueArray = RemoveDuplicatesPreservingOrder(originalArray);

                // Выводим результат
                string resultText = $"Исходный массив ({originalArray.Count} элементов):\n";
                resultText += $"[{string.Join(", ", originalArray)}]\n\n";

                resultText += $"Массив без дубликатов ({uniqueArray.Count} элементов):\n";
                resultText += $"[{string.Join(", ", uniqueArray)}]\n\n";

                // Выявляем дубликаты
                var duplicates = originalArray.GroupBy(x => x)
                    .Where(g => g.Count() > 1)
                    .Select(g => $"{g.Key} (встречается {g.Count()} раз)")
                    .ToList();

                if (duplicates.Count > 0)
                {
                    resultText += $"Найденные дубликаты:\n";
                    resultText += string.Join("\n", duplicates);
                }
                else
                {
                    resultText += "Дубликатов не найдено";
                }

                tbArrayResult.Text = resultText;

                // Анализ сложности
                string complexityAnalysis = "📊 АНАЛИЗ СЛОЖНОСТИ:\n\n";
                complexityAnalysis += "Временная сложность: O(n)\n";
                complexityAnalysis += "  • Один проход по массиву: O(n)\n";
                complexityAnalysis += "  • Проверка наличия в HashSet: O(1)\n";
                complexityAnalysis += "  • Итого: O(n)\n\n";
                complexityAnalysis += "Пространственная сложность: O(n)\n";
                complexityAnalysis += "  • HashSet для отслеживания уникальных элементов: O(n)\n";
                complexityAnalysis += "  • Выходной список: O(n)\n";
                complexityAnalysis += "  • Итого: O(n)\n\n";
                complexityAnalysis += "Алгоритм: используется HashSet для O(1) проверки уникальности";

                tbComplexityAnalysis.Text = complexityAnalysis;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Удаление дубликатов с сохранением порядка
        private List<string> RemoveDuplicatesPreservingOrder(List<string> array)
        {
            HashSet<string> seen = new HashSet<string>();
            List<string> result = new List<string>();

            foreach (var item in array)
            {
                if (!seen.Contains(item))
                {
                    seen.Add(item);
                    result.Add(item);
                }
            }

            return result;
        }

        // ======================== ЗАДАЧА 2.5: Поиск анаграмм ========================
        private void BtnFindAnagrams_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchWord = tbSearchWord.Text.Trim();
                string searchText = tbSearchText.Text;

                if (string.IsNullOrWhiteSpace(searchWord) || string.IsNullOrWhiteSpace(searchText))
                {
                    MessageBox.Show("Заполните оба поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Находим все анаграммы
                var anagrams = FindAnagrams(searchWord, searchText);

                // Выводим результаты
                string resultText = $"Поиск анаграмм для слова: \"{searchWord}\"\n\n";

                if (anagrams.Count > 0)
                {
                    resultText += $"✓ Найдено {anagrams.Count} анаграмм:\n\n";
                    resultText += string.Join("\n", anagrams.Select((w, i) => $"{i + 1}. {w}"));
                }
                else
                {
                    resultText += "✗ Анаграммы не найдены";
                }

                tbAnagramResult.Text = resultText;

                // Статистика
                string stats = $"📈 Статистика:\n";
                stats += $"• Исходное слово: \"{searchWord}\" ({searchWord.Length} букв)\n";
                stats += $"• Всего слов в тексте: {searchText.Split(new[] { ' ', ',', '.', '!', '?' }, StringSplitOptions.RemoveEmptyEntries).Length}\n";
                stats += $"• Найдено анаграмм: {anagrams.Count}\n";
                stats += $"• Уникальные буквы: {new string(searchWord.ToLower().Distinct().OrderBy(x => x).ToArray())}";

                tbAnagramStats.Text = stats;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Поиск всех подстрок, которые являются анаграммами
        private List<string> FindAnagrams(string word, string text)
        {
            // Нормализуем слово поиска
            string normalizedWord = NormalizeWord(word);
            string sortedSearchWord = new string(normalizedWord.OrderBy(c => c).ToArray());

            // Извлекаем все слова из текста
            string[] words = text.Split(new[] { ' ', ',', '.', '!', '?', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            List<string> anagrams = new List<string>();

            foreach (var w in words)
            {
                string normalizedW = NormalizeWord(w);

                // Проверяем, является ли слово анаграммой
                if (normalizedW.Length == normalizedWord.Length)
                {
                    string sortedW = new string(normalizedW.OrderBy(c => c).ToArray());
                    if (sortedW == sortedSearchWord && normalizedW != normalizedWord)
                    {
                        anagrams.Add(w);
                    }
                }
            }

            return anagrams;
        }

        // Нормализация слова (приводит в нижний регистр, удаляет пунктуацию)
        private string NormalizeWord(string word)
        {
            return new string(word.ToLower().Where(c => char.IsLetter(c) || char.IsDigit(c)).ToArray());
        }
    }
}